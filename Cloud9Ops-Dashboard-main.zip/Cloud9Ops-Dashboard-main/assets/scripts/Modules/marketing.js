export function initMarketing(){}
