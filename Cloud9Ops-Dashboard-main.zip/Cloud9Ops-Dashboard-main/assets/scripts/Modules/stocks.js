export function initStocks(){}
